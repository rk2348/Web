// --- 1. ページの状態を取得して表示を更新する関数 ---
async function refreshCurrentInfo() {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab.url || tab.url.startsWith("chrome://")) {
    document.getElementById("currentInfo").textContent = "このページでは使用できません";
    return;
  }

  // ページ内の実際のスタイルを計測
  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: () => {
      const style = window.getComputedStyle(document.body);
      const fontSizePx = parseFloat(style.fontSize);
      const lineHeightVal = style.lineHeight;

      let displayLh = "不明";
      
      if (lineHeightVal === 'normal') {
        displayLh = "約1.2px";
      } else if (lineHeightVal.includes("px")) {
        const lhPx = parseFloat(lineHeightVal);
        if (fontSizePx > 0) {
          displayLh = (lhPx / fontSizePx).toFixed(2);
        }
      } else if (!isNaN(parseFloat(lineHeightVal))) {
        displayLh = parseFloat(lineHeightVal).toFixed(2);
      }

      return {
        size: fontSizePx ? Math.round(fontSizePx) + "px" : "不明",
        lh: displayLh
      };
    }
  });

  if (results && results[0] && results[0].result) {
    const data = results[0].result;
    document.getElementById("currentInfo").textContent = `現在の基準: 文字 ${data.size} / 行間 ${data.lh}`;
  } else {
    document.getElementById("currentInfo").textContent = "情報の取得に失敗しました";
  }
}

// ポップアップが開いたときに実行
document.addEventListener('DOMContentLoaded', refreshCurrentInfo);


// --- 2. 変更を適用する機能（共通処理） ---
async function applySettings(settings) {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    args: [settings],
    function: (s) => {
      if (!document.body.dataset.originalFontSize) {
        const style = window.getComputedStyle(document.body);
        const fs = parseFloat(style.fontSize);
        let lhPx = parseFloat(style.lineHeight);
        if (isNaN(lhPx)) lhPx = fs * 1.2;
        document.body.dataset.originalFontSize = fs;
        document.body.dataset.originalLineHeight = lhPx;
      }

      const styleId = "my-extension-style";
      const oldStyle = document.getElementById(styleId);
      if (oldStyle) oldStyle.remove();

      const style = document.createElement('style');
      style.id = styleId;
      const textSelectors = 'body, p, h1, h2, h3, h4, h5, h6, li, td, th, div, span, dl, dt, dd, blockquote, pre';
      
      let cssRules = `
        ${textSelectors} { font-size: ${s.fontSize}px !important; }
        ${textSelectors} { line-height: ${s.lineHeight} !important; }
        ${textSelectors} { color: ${s.textColor} !important; background-color: transparent; }
        body { background-color: ${s.bgColor} !important; }
        a, a * { color: ${s.linkColor} !important; }
      `;

      // 朝日新聞（asahi.com）の場合のみ、写真と広告を非表示にする設定を追加
      if (window.location.hostname.includes('sankei.com')) {
        const hideSelectors = 'img, figure, picture, [class*="Ad"], [id*="Ad"], .p-ad, .c-ad';
        cssRules += `
          ${hideSelectors} { display: none !important; }
        `;
      }

      style.textContent = cssRules;
      document.head.appendChild(style);

      const originalFs = parseFloat(document.body.dataset.originalFontSize);
      const originalLh = parseFloat(document.body.dataset.originalLineHeight);
      const targetFs = parseFloat(s.fontSize);
      const targetLhPx = targetFs * parseFloat(s.lineHeight);
      const scaleRatio = originalLh > 0 ? targetLhPx / originalLh : 1.0;
      
      const allImages = document.querySelectorAll('img, svg, video');
      allImages.forEach(img => {
        if (!img.dataset.originalWidth) {
          const w = img.clientWidth || img.naturalWidth || 0;
          if (w > 20) {
            img.dataset.originalWidth = w;
            img.dataset.originalStyleWidth = img.style.width; 
          }
        }
        if (img.dataset.originalWidth) {
          img.style.width = `${parseFloat(img.dataset.originalWidth) * scaleRatio}px`;
          img.style.maxWidth = '100%';
          img.style.height = 'auto';
          img.classList.add('my-scaled-img');
        }
      });
    }
  });

  // スタイル適用後に表示を更新
  refreshCurrentInfo();
}

// --- 3. おすすめ設定ボタンの処理 ---
document.getElementById("presetBtn").addEventListener("click", () => {
  const settings = {
    fontSize: "25",
    lineHeight: "2.0",
    textColor: '#000000',
    bgColor: '#ffffff',
    linkColor: '#0000EE'
  };
  applySettings(settings);
});


// --- 4. 元に戻す機能 ---
document.getElementById("resetBtn").addEventListener("click", async () => {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: () => {
      const style = document.getElementById("my-extension-style");
      if (style) style.remove();
      
      const scaledImages = document.querySelectorAll('.my-scaled-img');
      scaledImages.forEach(img => {
        img.style.width = img.dataset.originalStyleWidth || '';
        img.style.maxWidth = '';
        img.style.height = '';
        delete img.dataset.originalWidth;
        delete img.dataset.originalStyleWidth;
        img.classList.remove('my-scaled-img');
      });

      delete document.body.dataset.originalFontSize;
      delete document.body.dataset.originalLineHeight;
    }
  });

  // リセット後に表示を更新
  refreshCurrentInfo();
});